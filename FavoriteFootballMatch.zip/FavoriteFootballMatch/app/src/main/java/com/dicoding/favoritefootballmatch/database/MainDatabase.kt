package com.dicoding.favoritefootballmatch.database

object MainDatabase {
    const val DATABASE_EVENT_NAME = "event.db"
}