package com.dicoding.favoritefootballmatch.view

interface BaseView {
    fun showLoading()
    fun hideLoading()
}